/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1_deber1_ricardo_paredes;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class Ejercicio1_Deber1_Ricardo_Paredes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner (System.in); 

        int valorIngresado;
        int unidad;
        int decena;
        int centena;
        int unidadDeMil;
        int decenaDeMil;
        System.out.print("Ingrese el número de 5 dígitos: ");
        valorIngresado = entrada.nextInt();
        if(((valorIngresado/ 10000)>0)&&((valorIngresado/10000)<=9)){
           System.out.print("El valor Ingresado fue: "+valorIngresado+" Y sus cifras son: \n");
           decenaDeMil=valorIngresado/10000;
           unidadDeMil=(valorIngresado -(decenaDeMil*10000))/1000;
           centena=(valorIngresado -((decenaDeMil*10000)+unidadDeMil*1000))/100;
           decena=(valorIngresado -((centena*100)+(unidadDeMil*1000)+(decenaDeMil*10000)))/10;
           unidad=valorIngresado%10;
           System.out.print("Decena de Mil es: "+decenaDeMil+"\n");
           System.out.print("Unidad de Mil es: "+unidadDeMil+"\n");
           System.out.print("Centena es: "+centena+"\n");
           System.out.print("Decena es: "+decena+"\n");
           System.out.print("Unidad es: "+unidad+"\n"); 
           System.out.print("Y representado en una sola hilera: \n");
           System.out.println(decenaDeMil+"   "+unidadDeMil+"   "+centena+"   "+decena+"   "+unidad);
        }else{
            System.out.println("El número Ingresado no es un número de 5 cifras, por favor, ingréselo nuevamente");
        }
    }
    
}
