/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio3_deber1_ricardo_paredes;
import java.util.Scanner;
 /**
 *
 * @author User
 */
public class Ejercicio3_Deber1_Ricardo_Paredes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner (System.in);
        int []numeros = new int [5] ;
        int contador=0; //Cuenta los 0's
        int counter=0;  //Cuenta los números positivos
        int compteur=0; //Cuenta los números Negativos
        for(int i=0;i<5;i++){
        System.out.print("Por favor, Ingresar el "+(i+1)+"° número entero : ");
        numeros[i] = entrada.nextInt();}
        System.out.println("Los números ingresados son:");
        for(int j=0;j<5;j++){
        System.out.print(numeros[j]+"\t\t");
        if(numeros[j]==0){
            contador++;
        }else{
            if(numeros[j]>0){
                counter++;
            }else{
                compteur++;
            }
        }}
        System.out.print("\nPor lo tanto, la cantidad de números positivos son: "+counter+"\n");
        System.out.print("Por lo tanto, la cantidad de números negativos son: "+compteur+"\n");
        System.out.print("Por lo tanto, la cantidad de 0's son: "+contador+"\n");
    }
    
}
