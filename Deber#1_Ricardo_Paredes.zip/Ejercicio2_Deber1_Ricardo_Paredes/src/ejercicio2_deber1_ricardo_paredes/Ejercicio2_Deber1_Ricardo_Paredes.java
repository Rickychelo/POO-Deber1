/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2_deber1_ricardo_paredes;
import java.util.Scanner;
/**
 *
 * @author User
 */
public class Ejercicio2_Deber1_Ricardo_Paredes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        System.out.print("Los 10 primeros números en estado base, al cuadrado y al cubo son: \n");
        System.out.print("Base"+"   \t\t"+"Al Cuadrado"+"\t\t\t"+"Al Cubo \n");
        for(int i=1; i<=10;i++){
            System.out.print(i+"\t\t\t"+(i*i)+"\t\t\t"+(i*i*i)+"\n");
        }
    }
}
